package TestSuite_Twoplugs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.Assert;
import org.testng.annotations.*;

public class TP_003 {

public String baseURL="https://qatest.twoplugs.com/";
WebDriver driver;
public String expected = null;
public String actual = null;
	
@BeforeTest
public void OpenURL() {
	
System.setProperty("webdriver.chrome.driver", "./Drivers1//chromedriver.exe");
driver = new ChromeDriver();
driver.get(baseURL);
driver.manage().window().maximize(); 
  }

@Test
public void Login_Invalid () {

driver.findElement(By.xpath("/html/body/div/header/div/ul/li[2]/a/span")).click();
driver.findElement(By.xpath("/html/body/div[7]/div/div/form/div[2]/div[5]/div/div/a")).click();
driver.findElement(By.name("email")).sendKeys("galaxywrong.com");
driver.findElement(By.name("password")).sendKeys("qateswrong");
driver.findElement(By.xpath("/html/body/div[7]/div/form/div[5]/ul/li[2]/button/span")).click();
expected = "INVALID EMAIL/PASSWORD";
actual = driver.getTitle();
if(actual.contains(expected))
	System.out.println("test passed - Error:invalid email/password");

driver.close();
	
	
}
}
