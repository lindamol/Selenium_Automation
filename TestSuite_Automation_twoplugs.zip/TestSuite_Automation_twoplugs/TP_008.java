package TestSuite_Twoplugs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.*;


public class TP_008 {
public String baseURL="https://qatest.twoplugs.com/";
WebDriver driver;
public String expected = null;
public String actual = null;  
			
@BeforeTest
public void OpenURL() {
System.setProperty("webdriver.chrome.driver", "./Drivers1//chromedriver.exe");
driver = new ChromeDriver();
driver.get(baseURL);
}
@BeforeClass
public void Login() {
driver.findElement(By.xpath("/html/body/div/header/div/ul/li[2]/a/span")).click();
driver.findElement(By.xpath("/html/body/div[7]/div/div/form/div[2]/div[5]/div/div/a")).click();
driver.findElement(By.name("email")).sendKeys("seal@mailinator.com");
driver.findElement(By.name("password")).sendKeys("qatest2plugs");
driver.findElement(By.xpath("/html/body/div[7]/div/form/div[5]/ul/li[2]/button/span")).click();
}

@Test (priority=1)
public void Verify_Create_Need () {
driver.findElement(By.xpath("/html/body/div[7]/nav/div/form/div[2]")).click();
driver.findElement(By.xpath("/html/body/div[7]/nav/div/form/div[2]/ul/li[2]/a")).click();
driver.findElement(By.name("name")).sendKeys("Baker cake");
driver.findElement(By.id("description")).sendKeys("Need someone to bake cake.");
driver.findElement(By.xpath("//*[@id=\"category_id-styler\"]/div[1]/div[1]")).click();
driver.findElement(By.xpath("//*[@id=\"category_id-styler\"]/div[2]/ul/li[3]")).click();
driver.findElement(By.xpath("//*[@id=\"subcategory_id-styler\"]/div[1]/div[2]/div")).click();
driver.findElement(By.name("price")).sendKeys("100");
driver.findElement(By.xpath("//*[@id=\"imagegroup\"]/div[5]/ul/li[2]/button/span")).click();
expected="twoPLUGS - A plug for your Service and another for your Need";
actual=driver.getTitle();
Assert.assertEquals(actual, expected);
}
@Test (priority=2)
public void Verify_Update_Need (){
	driver.findElement(By.xpath("//span[contains(text(),'Hi seal')]")).click();
	driver.findElement(By.xpath("//span[contains(text(),'Profile')]")).click();
driver.findElement(By.xpath("//tr[1]//td[2]//ul[1]//li[1]//a[1]//span[1]")).click();
driver.findElement(By.id("description")).clear();
driver.findElement(By.id("description")).sendKeys("Need someone to bake cake.");
driver.findElement(By.xpath("//span[contains(text(),'Save')]")).click();
expected="twoPLUGS - A plug for your Service and another for your Need";
actual=driver.getTitle();
Assert.assertEquals(actual, expected);
}

@Test (priority=3)
public void Verify_Delete_Need ()  {
	driver.findElement(By.xpath("//span[contains(text(),'Hi seal')]")).click();
	driver.findElement(By.xpath("//span[contains(text(),'Profile')]")).click();
driver.findElement(By.xpath("//tr[1]//td[2]//ul[1]//li[2]//a[1]//span[1]")).click();

driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
driver.findElement(By.xpath("/html/body/div[7]/div[2]/div/div/form/div[2]/div/ul/li[2]/a/span")).click();


expected="twoPLUGS - A plug for your Service and another for your Need";
actual=driver.getTitle();
Assert.assertEquals(actual, expected);
}
@AfterClass
public void CloseURL ()  {
driver.close();
}

}

