package TestSuite_Twoplugs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TP_021 {
	public  String baseURL= "https://qatest.twoplugs.com";
	WebDriver driver;
	    public String expected= null;
	    public String actual= null;
	   

	@BeforeTest
	 public void beforetest()  {  
	 
	System.setProperty("webdriver.chrome.driver","./Drivers1//chromedriver.exe");
	driver = new ChromeDriver();
	driver.get(baseURL);
	driver.manage().window().maximize();}
	 

	  @Test (priority=1)
	 
	  public void login() throws InterruptedException  {
      //Login with valid credentials
	driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();
	driver.findElement(By.xpath("//input[@id='signInEmail']")).sendKeys("seal@mailinator.com");
	driver.findElement(By.xpath("//input[@id='signInPassword']")).sendKeys("qatest2plugs");
	driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();    
	  }
	  
	  @Test (priority=2)
	 // Testing whether the footer links are taking to the appropriate page
	  public void footerfeedback() throws InterruptedException  {
		  driver.findElement(By.xpath(" //a[contains(text(),'Feedback')]")).click();	
	  }
		  @Test (priority=3)
		     //assertions
		    public void assertion1() {

		    String actual= driver.findElement(By.xpath("//h4[contains(text(),'We want to hear from you')]")).getText();
		    String expected= "We want to hear from you";
		    if (actual.contains(expected))
		    System.out.println("test case passed");
		    else
		    System.out.println("test case failed");
		      }
		  
		  @Test (priority=4)
			 // Testing whether the footer links are taking to the appropriate page
			  public void footersupport() throws InterruptedException  {
				  driver.findElement(By.xpath("//a[contains(text(),'Support')] ")).click();	
			  }
				  
				     //assertions
				    public void assertion2() {

				    String actual= driver.findElement(By.xpath("//div[contains(text(),'Support Center Topics')]")).getText();
				    String expected= "Support Center Topics";
				    if (actual.contains(expected))
				    System.out.println("test case passed");
				    else
				    System.out.println("test case failed");
				      }
		  
 
				   
				  @Test (priority=6)
					 // Testing whether the footer links are taking to the appropriate page
					  public void footerprivacypolicy() throws InterruptedException  {
						  driver.findElement(By.xpath("//a[contains(text(),'Privacy policy')]")).click();	
					  }
						  
						     //assertions
						    public void assertion3() {

						    String actual= driver.findElement(By.xpath("//h2[contains(text(),'Privacy Policy')]")).getText();
						    String expected= "Privacy Policy";
						    if (actual.contains(expected))
						    System.out.println("test case passed");
						    else
						    System.out.println("test case failed");
						      }
				  
						  @Test (priority=8)
							 // Testing whether the footer links are taking to the appropriate page
							  public void footertermsofuse() throws InterruptedException  {
								  driver.findElement(By.xpath("//a[contains(text(),'Terms of use')]")).click();	
							  }
								  
								     //assertions
								    public void assertion4() {

								    String actual= driver.findElement(By.xpath("//h2[contains(text(),'Terms of Use')]")).getText();
							
								    String expected= "Terms of Use";
								    if (actual.contains(expected))
								    System.out.println("test case passed");
								    else
								    System.out.println("test case failed");
								      }
								  @AfterTest
								     // closing browser
								  public void Closingbrowser() {
								  driver.close();
								  }
						  
}
