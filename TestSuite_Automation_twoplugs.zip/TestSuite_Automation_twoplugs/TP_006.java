package TestSuite_Twoplugs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;



public class TP_006 {
	
public String baseURL="https://qatest.twoplugs.com/";
WebDriver driver;
public String expected = null;
public String actual = null;  
	
@BeforeTest
public void OpenURL() {
System.setProperty("webdriver.chrome.driver", "./Drivers1//chromedriver.exe");
driver = new ChromeDriver();
driver.get(baseURL);
driver.manage().window().maximize(); 
}
@BeforeClass
public void Login() {
driver.findElement(By.xpath("/html/body/div/header/div/ul/li[2]/a/span")).click();
driver.findElement(By.xpath("/html/body/div[7]/div/div/form/div[2]/div[5]/div/div/a")).click();
driver.findElement(By.name("email")).sendKeys("seal@mailinator.com");
driver.findElement(By.name("password")).sendKeys("qatest2plugs");
driver.findElement(By.xpath("/html/body/div[7]/div/form/div[5]/ul/li[2]/button/span")).click();

driver.findElement(By.id("exampleInputAmount")).sendKeys("hulk");
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
driver.findElement(By.xpath("/html/body/div[7]/nav/div/form/div[3]/div[2]/p/strong")).click();
  }
@Test (priority=1)
public void Ver_follow_ () {
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
driver.findElement(By.xpath("//*[@id=\"followuserlogo\"]/span")).click();
expected="twoPLUGS - A plug for your Service and another for your Need";
actual=driver.getTitle();
Assert.assertEquals(actual, expected);
driver.findElement(By.id("cancelButton")).click();	
  }
@Test (priority=2)
public void Ver_Sendeeds() {
driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
driver.findElement(By.id("cancelButton")).click();	
driver.findElement(By.xpath("//div[@class='top']//li[2]//a[1]")).click();

driver.findElement(By.xpath("//input[@id='transferAmount']")).sendKeys("10");
//driver.findElement(By.id("transferAmount")).sendKeys("1");
//driver.findElement(By.id("transfer_id")).click();
driver.findElement(By.xpath("//span[contains(text(),'TRANSFER')]")).click();
//span[contains(text(),'TRANSFER')]
expected="twoPLUGS - A plug for your Service and another for your Need";
actual=driver.getTitle();
Assert.assertEquals(actual, expected);
}
@Test (priority=3)
public void Ver_message () {
driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
driver.findElement(By.xpath("//*[@id=\"TransdferModal\"]/div/div/form/div[2]/div/ul/li[1]/button/span")).click();	
driver.findElement(By.xpath("//*[@id=\"transderform\"]/div[4]/ul/li[1]/a/span")).click();
driver.findElement(By.id("messageforperosnal")).click();
driver.findElement(By.id("messagetitle")).sendKeys("test");
driver.findElement(By.id("messagecontent")).sendKeys("test");
driver.findElement(By.id("message_send")).click();
expected="twoPLUGS - A plug for your Service and another for your Need";
actual=driver.getTitle();
Assert.assertEquals(actual, expected);
}
@Test (priority=4)
public void Ver_Report () {
driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
driver.findElement(By.xpath("//span[@class='w-icons-profileCtrl4']")).click();
driver.findElement(By.id("reportSubject")).sendKeys("test");
driver.findElement(By.name("content")).sendKeys("test");
driver.findElement(By.xpath("//*[@id=\"compliantform\"]/div[4]/ul/li[2]/button")).click();
expected="twoPLUGS - A plug for your Service and another for your Need";
actual=driver.getTitle();
Assert.assertEquals(actual, expected);
}
@AfterClass
public void CloseURL() {
driver.close();
	
}

}
