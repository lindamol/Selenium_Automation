package TestSuite_Twoplugs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
//import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TP_011 {
	public  String baseURL= "https://qatest.twoplugs.com";
	WebDriver driver;
	    public String expected= null;
	    public String actual= null;
	   

	@BeforeTest
	 public void beforetest()  {  
	 
	System.setProperty("webdriver.chrome.driver","./Drivers1//chromedriver.exe");
	driver = new ChromeDriver();
	driver.get(baseURL);
	driver.manage().window().maximize();}
	 

	  @Test (priority=1)
	  public void login() throws InterruptedException  {
      //Login with valid credentials
	driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();
	driver.findElement(By.xpath("//input[@id='signInEmail']")).sendKeys("seal@mailinator.com");
	driver.findElement(By.xpath("//input[@id='signInPassword']")).sendKeys("qatest2plugs");
	driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();    
	  }
	  

	  @Test (priority=2)
	  public void buytheservice() throws InterruptedException  {
      //buy the service by clicking on I want this button
	
	driver.findElement(By.xpath("//span[contains(text(),'Plugs')]")).click();    
	driver.findElement(By.xpath("//a[contains(text(),'Services')]")).click();
	driver.findElement(By.xpath("//tr[1]//td[1]//div[1]//div[2]//div[1]//a[1]")).click();
	driver.findElement(By.xpath("//span[contains(text(),'I want this')]")).click();    
	Thread.sleep(300);
	driver.findElement(By.xpath("//div[@id='chk_buyer_disclaimer-styler']")).click();
	driver.findElement(By.xpath("//span[contains(text(),'Buy')]")).click();
	  }
	  @Test (priority=3)
		//adding assertion for buying a service
		public void biddingsent() {
			String actual=driver.findElement(By.xpath("//h3[contains(text(),'Confirm Transaction')]")).getText();
			 String expected= "Confirm Transaction";
			  if (actual.contains(expected))
			  System.out.println("test case passed");
			  else
			  System.out.println("test case failed");
		}
	  @AfterTest
	    // closing browser
	 public void Closingbrowser() {
	 driver.close();
	 }
	
	  }