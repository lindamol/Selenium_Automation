package TestSuite_Twoplugs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TP_024 {
	public  String baseURL= "https://qatest.twoplugs.com";
	WebDriver driver;
	    public String expected= null;
	    public String actual= null;
	   

	@BeforeTest
	 public void beforetest()  {  
	 
	System.setProperty("webdriver.chrome.driver","./Drivers1//chromedriver.exe");
	driver = new ChromeDriver();
	driver.get(baseURL);
	driver.manage().window().maximize();}
	 

	  @Test (priority=1)
	 
	  public void login() throws InterruptedException  {
      //Login with valid credentials
	driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();
	driver.findElement(By.xpath("//input[@id='signInEmail']")).sendKeys("seal@mailinator.com");
	driver.findElement(By.xpath("//input[@id='signInPassword']")).sendKeys("qatest2plugs");
	driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();    
	  }
	  @Test (priority=2)
	  public void referafriend() throws InterruptedException {
		  //Testing whether a user can refer a friend
		  driver.findElement(By.xpath("//span[@class='caret']")).click();
		  driver.findElement(By.xpath("//span[contains(text(),'Settings')]")).click();
		  driver.findElement(By.xpath("//li[7]//a[1]")).click();
		  driver.findElement(By.xpath("//input[@id='email_input'] ")).sendKeys("galaxy@mailinator.com");    
		  
		 driver.findElement(By.xpath("//button[@class='btn btn-success w-btn-success email_btn'] ")).click();
	  }
	  
	  
	     //assertions
	    public void assertions() {

	    String actual= driver.findElement(By.xpath("//div[contains(text(),'Referral emails has been sent out')]")).getText();
	    String expected= "Referral emails has been sent out";
	    if (actual.contains(expected))
	    System.out.println("test case passed");
	    else
	    System.out.println("test case failed");
	      }
	  
	  @AfterTest
	     // closing browser
	  public void Closingbrowser() {
	  driver.close();
	  }
}