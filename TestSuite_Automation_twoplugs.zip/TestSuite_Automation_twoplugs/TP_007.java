package TestSuite_Twoplugs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
//import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
public class TP_007 {
	
	
	//Launching the browser
	public  String baseURL= "https://qatest.twoplugs.com";
	WebDriver driver;
	    public String expected= null;
	    public String actual= null;
	   

	@BeforeTest
	//setting the drivers
	 public void beforetest()  {  
	 
	System.setProperty("webdriver.chrome.driver","./Drivers1//chromedriver.exe");
	driver = new ChromeDriver();
	driver.get(baseURL);
	driver.manage().window().maximize();}
	 

	  @Test (priority=1)
	  public void Login() throws InterruptedException  {
   
	driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();
	driver.findElement(By.xpath("//input[@id='signInEmail']")).sendKeys("seal@mailinator.com");
	driver.findElement(By.xpath("//input[@id='signInPassword']")).sendKeys("qatest2plugs");
	 driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();
	  }
	  @Test(priority=2)
	  
	  public void create_service()  {

			driver.findElement(By.xpath("//span[contains(text(),'Create New')]")).click();
			driver.findElement(By.xpath("//a[contains(text(),'Service')]")).click();
			driver.findElement(By.xpath("//input[@id='name']")).sendKeys("Pet care");
			driver.findElement(By.xpath("//div[@id='category_id-styler']//div[@class='jq-selectbox__trigger-arrow'] ")).click();
			driver.findElement(By.xpath("//li[contains(text(),'Animals & Agriculture')]")).click();
			driver.findElement(By.xpath("//body/div[contains(@class,'wrapper')]/div[contains(@class,'container')]/form[contains(@class,'signIn profileRoom addServiceForm')]/div[contains(@class,'group')]/div[contains(@class,'')]/div[contains(@class,'form-controls cuSelect')]/div[@id='subcategory_id-styler']/div[1] ")).click();
			driver.findElement(By.xpath("//input[@id='price']")).sendKeys("12");
			driver.findElement(By.xpath("//button[contains(@class,'btn btn-success w-btn-success')]//span[contains(@class,'help')][contains(text(),'Create')]")).click();
	  }
			
			  
			  public void assert_for() {
			 
			  String actual= driver.findElement(By.xpath("//div[contains(text(),'Pet Service')]")).getText();
			  String expected= "Pet Service";
			  if (actual.contains(expected))
			  System.out.println("Test case passed");
			  else
			  System.out.println("Test case failed");
			  }
			
			@Test (priority=4)
			
			public void update_service() {
				driver.findElement(By.xpath("//a[@class='pull-right edit-link']")).click();
				driver.findElement(By.xpath("//input[@id='price']")).sendKeys("70");
				driver.findElement(By.xpath("//ul[@class='line-btn pull-right']//button[@class='btn btn-success w-btn-success'] ")).click();
			}
				
				//adding assertion for service update
				public void assert_for_updateservice() {
					String actual=driver.findElement(By.xpath("//div[contains(text(),'Service has been updated')]")).getText();
					 String expected= "Service has been updated";
					  if (actual.contains(expected))
					  System.out.println("test case passed");
					  else
					  System.out.println("test case failed");
					  }
					
				@Test (priority=6)
				
				public void delete_service()throws InterruptedException {
					//driver.findElement(By.xpath("//button[@class='navbar-toggle']//span[3]")).click();
					driver.findElement(By.xpath("//span[@class='caret']")).click();	
					Thread.sleep(200);
					driver.findElement(By.xpath("//span[contains(text(),'Profile')]")).click();
					driver.findElement(By.xpath("//tr[1]//td[4]//ul[1]//li[2]//a[1]//span[1]")).click();
					Thread.sleep(200);
					driver.findElement(By.xpath("//span[contains(text(),'I want to delete')]")).click();
				}
				
				
				public void assert_for_deleteservice() {
					String actual=driver.findElement(By.xpath("//div[contains(text(),'Service has been deleted')]")).getText();
					 String expected= "Service has been deleted";
					  if (actual.contains(expected))
					  System.out.println("test case passed");
					  else
					  System.out.println("test case failed");
					  }
				 @AfterTest 
			     
			  public void Closingbrowser() {
			  driver.close();}
				} 