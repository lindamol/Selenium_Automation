package TestSuite_Twoplugs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class TP_001 {
	public String baseURL="https://qatest.twoplugs.com/";
	WebDriver driver;
	public String expected = null;
	public String actual = null;

	@BeforeMethod
	public void OpenURL() {
	System.setProperty("webdriver.chrome.driver", "./Drivers1//chromedriver.exe");
	driver = new ChromeDriver();
	driver.get(baseURL);
	driver.manage().window().maximize(); 
	  }

	@Test
	public void Signup_invalid_user () {
	driver.findElement(By.xpath("//ul[@class='control-bar']//span[@class='help'][contains(text(),'Join Now For Free')]")).click();
	driver.findElement(By.name("username")).clear();
	driver.findElement(By.name("username")).sendKeys("wrongval445");
	driver.findElement(By.name("email")).sendKeys("hello@world.com");
	driver.findElement(By.name("password")).clear();
	driver.findElement(By.name("password")).sendKeys("hello");
	driver.findElement(By.xpath("//span[contains(text(),'SIGN UP')]")).click();
	expected="Username must start and end with an alphanumeric character and may also contain underscores or dashes";
	actual=driver.getTitle();
	if(actual.contains(expected))
		System.out.println("Test Passed");
	driver.close();

	}

  
}
