package TestSuite_Twoplugs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TP_017 {
	public  String baseURL= "https://qatest.twoplugs.com";
	WebDriver driver;
	    public String expected= null;
	    public String actual= null;
	   

	@BeforeTest
	 public void beforetest()  {  
	 
	System.setProperty("webdriver.chrome.driver","./Drivers1//chromedriver.exe");
	driver = new ChromeDriver();
	driver.get(baseURL);
	driver.manage().window().maximize();}
	 

	  @Test (priority=1)
	  public void login() throws InterruptedException  {
      //Login with valid credentials
	driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();
	driver.findElement(By.xpath("//input[@id='signInEmail']")).sendKeys("seal@mailinator.com");
	driver.findElement(By.xpath("//input[@id='signInPassword']")).sendKeys("qatest2plugs");
	driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();    
	  }
	
	  @Test (priority=2)
	  public void filingcomplaint() throws InterruptedException {
		  //Testing whether he can file a complaint after the transaction
		  driver.findElement(By.xpath("/html/body/div[7]/nav/div/div[2]/ul/li[2]/a/span[2]")).click();
		  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		  driver.findElement(By.xpath("/html[1]/body[1]/div[7]/div[1]/table[2]/tbody[1]/tr[6]/td[7]/a[1]/i[1]")).click();
		  driver.findElement(By.xpath("/html[1]/body[1]/div[7]/div[1]/table[2]/tbody[1]/tr[6]/td[7]/a[1]/i[1]")).click();
		  driver.findElement(By.id("reportSubject")).sendKeys("Complaint on service");
		  driver.findElement(By.name("content")).sendKeys("Not satisfied with your service");
		  driver.findElement(By.xpath("//*[@id=\"compliantform\"]/div[5]/ul/li[2]/button/span")).submit();

	  }
	  
	    public void assertions() {

	    String actual= driver.findElement(By.xpath("/html[1]/body[1]/div[7]/div[1]/div[1] ")).getText();
	    String expected= "Complain submitted";
	    if (actual.contains(expected))
	    System.out.println("test case passed");
	    else
	    System.out.println("test case failed");
	      }
	  
	   @AfterTest
	     // closing browser
	  public void Closingbrowser() {
	  driver.close();
	  }
}
