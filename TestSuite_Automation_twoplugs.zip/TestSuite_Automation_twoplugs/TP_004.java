package TestSuite_Twoplugs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class TP_004 {
public String baseURL="https://qatest.twoplugs.com/";
WebDriver driver;
public String expected = null;
public String actual = null;

@BeforeClass
public void OpenURL() {
System.setProperty("webdriver.chrome.driver", "./Drivers1//chromedriver.exe");
driver = new ChromeDriver();
driver.get(baseURL);
driver.manage().window().maximize();
  }
		
@BeforeMethod
public void Login() {
driver.findElement(By.xpath("/html/body/div/header/div/ul/li[2]/a/span")).click();
driver.findElement(By.xpath("/html/body/div[7]/div/div/form/div[2]/div[5]/div/div/a")).click();
driver.findElement(By.name("email")).sendKeys("seal@mailinator.com");
driver.findElement(By.name("password")).sendKeys("qatest2plugs");
driver.findElement(By.xpath("/html/body/div[7]/div/form/div[5]/ul/li[2]/button/span")).click();
}

@Test 
public void Search_for_Service_or_Need () {
driver.findElement(By.xpath("/html/body/div[7]/nav/div/div[2]/ul/li[1]/a/span[2]")).click();
driver.findElement(By.id("searchInput")).sendKeys("beauty");
driver.findElement(By.xpath("//*[@id=\"services\"]/div/div[2]/button/span")).click();
expected="twoPLUGS - A plug for your Service and another for your Need";
actual = driver.getTitle();
Assert.assertEquals(actual, expected);
driver.close();
}

}