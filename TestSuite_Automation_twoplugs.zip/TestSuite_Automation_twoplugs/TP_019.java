package TestSuite_Twoplugs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TP_019 {
	
	  public  String baseURL= "https://qatest.twoplugs.com";
	WebDriver driver;
	    public String expected= null;
	    public String actual= null;
	   

	@BeforeTest
	 public void beforetest()  {  
	 
	System.setProperty("webdriver.chrome.driver","./Drivers1//chromedriver.exe");
	driver = new ChromeDriver();
	driver.get(baseURL);
	driver.manage().window().maximize();}
	 

	  @Test (priority=1)
	  public void login() throws InterruptedException  {
      //Login with valid credentials
	driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();
	driver.findElement(By.xpath("//input[@id='signInEmail']")).sendKeys("seal@mailinator.com");
	driver.findElement(By.xpath("//input[@id='signInPassword']")).sendKeys("qatest2plugs");
	driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();    
	  }
	  @Test (priority=2)
	  public void changingthenetwork() throws InterruptedException {
		  //Testing whether a user can change the network
		  driver.findElement(By.xpath(" //a[@class='edit-link']")).click();
		  driver.findElement(By.xpath("//form[@class='profileRoom']//span[@class='help'][contains(text(),'Profile')] ")).click();
		  driver.findElement(By.xpath("//div[@id='stateDropdown-styler']//div[@class='jq-selectbox__trigger']  ")).click();    
		  driver.findElement(By.xpath("//li[contains(text(),'Manitoba')]")).click();
		  Thread.sleep(200);
		  driver.findElement(By.xpath("//span[contains(text(),'SAVE CHANGES')]")).click();  
	  }
	  
	  
	     //assertions
	   /* public void assertions() {

	    String actual= driver.findElement(By.xpath("//div[contains(text(),'Your profile has been updated')]")).getText();
	    String expected= "Your profile has been updated";
	    if (actual.contains(expected))
	    System.out.println("test case passed");
	    else
	    System.out.println("test case failed");
	      }
	  
	   @AfterTest
	     // closing browser
	  public void Closingbrowser() {
	  driver.close();
	  }*/
}
