package TestSuite_Twoplugs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.*;


public class TP_016 {
public String baseURL="https://qatest.twoplugs.com/";
WebDriver driver;
public String expected = null;
public String actual = null;

@BeforeTest
public void OpenURL () {
System.setProperty("webdriver.chrome.driver", "./Drivers1//chromedriver.exe");
driver=new ChromeDriver();
driver.get(baseURL);
}
@BeforeClass
public void Login ()  {
driver.findElement(By.xpath("/html/body/div/header/div/ul/li[2]/a/span")).click();
driver.findElement(By.xpath("/html/body/div[7]/div/div/form/div[2]/div[5]/div/div/a")).click();
driver.findElement(By.name("email")).sendKeys("seal@mailinator.com");
driver.findElement(By.name("password")).sendKeys("qatest2plugs");
driver.findElement(By.xpath("/html/body/div[7]/div/form/div[5]/ul/li[2]/button/span")).click();	
} 

@Test
public void Add_Service_Match_in_Settings() {
	driver.findElement(By.xpath("//span[contains(text(),'Hi seal')]")).click();
	driver.findElement(By.xpath("/html/body/div[7]/nav/div/div[2]/ul/li[4]/ul/li[2]/a/span[2]")).click();
	
driver.findElement(By.xpath("/html/body/div[7]/div/form/div[1]/nav/ul/li[3]/a/span")).click();
driver.findElement(By.xpath("//*[@id=\"match_type-styler\"]/div[1]/div[2]/div")).click();
driver.findElement(By.xpath("//*[@id=\"match_type-styler\"]/div[2]/ul/li[1]")).click();
driver.findElement(By.xpath("//*[@id=\"category_id-styler\"]/div[1]/div[1]")).click();
driver.findElement(By.xpath("//*[@id=\"category_id-styler\"]/div[2]/ul/li[15]")).click();
driver.findElement(By.xpath("//*[@id=\"subcategory_id-styler\"]/div[1]/div[1]")).click();
driver.findElement(By.xpath("//*[@id=\"set-tab-4\"]/div/form[2]/div[4]/button/span")).click();
expected="twoPLUGS - A plug for your Service and another for your Need";
actual=driver.getTitle();
Assert.assertEquals(actual, expected);
}
@AfterClass
public void CloseURL ()  {
driver.close();	
}
}