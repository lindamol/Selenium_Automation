package TestSuite_Twoplugs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TP_025 {
	//launching browser
			public  String baseURL= "https://qatest.twoplugs.com";
			WebDriver driver;
			    public String expected= null;
			    public String actual= null;
			   

			@BeforeTest
			 public void beforetest()  {  
			 //setting drivers
			System.setProperty("webdriver.chrome.driver","./Drivers1//chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(baseURL);
			driver.manage().window().maximize();
			}
			 

			  @Test (priority=1)
			  public void login() throws InterruptedException  {
		      //Login with valid credentials
			driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();
			driver.findElement(By.xpath("//input[@id='signInEmail']")).sendKeys("seal@mailinator.com");
			driver.findElement(By.xpath("//input[@id='signInPassword']")).sendKeys("qatest2plugs");
			driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).click();    
			  }
			  @Test (priority=2)
			  public void signout() throws InterruptedException  {
		      //Testing whether a user can sign out from twoplugs
			driver.findElement(By.xpath("//span[@class='caret']")).click();
			driver.findElement(By.xpath("//span[contains(text(),'Sign Out')]")).click();
			  }
			  
			 
			     //assertions
			    public void assertions() {

			    String actual= driver.findElement(By.xpath("//span[contains(text(),'LOG IN')]")).getText();
			    String expected= "LOG IN";
			    if (actual.contains(expected))
			    System.out.println("test case passed");
			    else
			    System.out.println("test case failed");
			      }
			  
			  @AfterTest
			     // closing browser
			  public void Closingbrowser() {
			  driver.close();
			  }
}
