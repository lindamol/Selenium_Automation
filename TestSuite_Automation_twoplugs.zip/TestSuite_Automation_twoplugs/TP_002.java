package TestSuite_Twoplugs;
//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class TP_002 {

public String baseURL="https://qatest.twoplugs.com/";
WebDriver driver;
public String expected = null;
public String actual = null;

@BeforeMethod
public void OpenURL() {
System.setProperty("webdriver.chrome.driver", "./Drivers1//chromedriver.exe");
driver = new ChromeDriver();
driver.get(baseURL);
driver.manage().window().maximize(); 
  }
	
@Test
public void Login_valid () {

driver.findElement(By.xpath("/html/body/div/header/div/ul/li[2]/a/span")).click();
driver.findElement(By.xpath("/html/body/div[7]/div/div/form/div[2]/div[5]/div/div/a")).click();
driver.findElement(By.name("email")).sendKeys("seal@mailinator.com");
driver.findElement(By.name("password")).sendKeys("qatest2plugs");
driver.findElement(By.xpath("/html/body/div[7]/div/form/div[5]/ul/li[2]/button/span")).click();
expected = "twoPLUGS - A plug for your Service and another for your Need";
actual = driver.getTitle();
Assert.assertEquals(actual, expected);
driver.close();
	
  }
}