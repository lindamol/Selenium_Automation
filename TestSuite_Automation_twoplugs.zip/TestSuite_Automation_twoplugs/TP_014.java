package TestSuite_Twoplugs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class TP_014 {
public String baseURL="https://qatest.twoplugs.com/";
WebDriver driver;
public String expected = null;
public String actual = null;

@BeforeTest
public void OpenURL () {
System.setProperty("webdriver.chrome.driver", "./Drivers1//chromedriver.exe");
driver=new ChromeDriver();
driver.get(baseURL);
}
@BeforeClass
public void Login ()  {
driver.findElement(By.xpath("/html/body/div/header/div/ul/li[2]/a/span")).click();
driver.findElement(By.xpath("/html/body/div[7]/div/div/form/div[2]/div[5]/div/div/a")).click();
driver.findElement(By.name("email")).sendKeys("seal@mailinator.com");
driver.findElement(By.name("password")).sendKeys("qatest2plugs");
driver.findElement(By.xpath("/html/body/div[7]/div/form/div[5]/ul/li[2]/button/span")).click();	
}
@Test
public void Send_eeds_Transfer_Icon () {
driver.findElement(By.id("exampleInputAmount")).sendKeys("wave");
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
driver.findElement(By.xpath("/html/body/div[7]/nav/div/form/div[3]/div[2]/p/strong")).click();
driver.findElement(By.xpath("/html/body/div[7]/section/div[1]/div/div[2]/div[2]/ul/li[2]/a/span")).click();
driver.findElement(By.id("transferAmount")).clear();
driver.findElement(By.id("transferAmount")).sendKeys("1");
driver.findElement(By.xpath("//*[@id=\"transfer_id\"]/span")).click();
driver.findElement(By.xpath("//*[@id=\"btn_transfer\"]/span")).click();
expected = "twoPLUGS - A plug for your Service and another for your Need";
actual = driver.getTitle();
Assert.assertEquals(actual, expected);
}
@AfterClass
public void CloseURL () {
driver.close();
}
}