package TestSuite_Twoplugs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;


public class TP_015 {
public String baseURL="https://qatest.twoplugs.com/";
WebDriver driver;
public String expected = null;
public String actual = null;

@BeforeTest
public void OpenURL () {
System.setProperty("webdriver.chrome.driver", "./Drivers1//chromedriver.exe");
driver=new ChromeDriver();
driver.get(baseURL);
}

@Test
public void Reset_Password_Clicking_Forgot_Password ()  {
driver.findElement(By.xpath("/html/body/div/header/div/ul/li[2]/a/span")).click();
driver.findElement(By.xpath("/html/body/div[7]/div/div/form/div[2]/div[5]/div/div/a")).click();	
driver.findElement(By.xpath("/html/body/div[7]/div/form/div[4]/div/a")).click();
driver.findElement(By.name("email")).sendKeys("hulk@mailinator.com");
driver.findElement(By.xpath("//span[contains(text(),'reset')]")).click();
expected="twoPLUGS - A plug for your Service and another for your Need";
actual=driver.getTitle();
Assert.assertEquals(actual, expected);
}
@AfterClass
public void CloseURL ()  {
driver.close();	
}



}
